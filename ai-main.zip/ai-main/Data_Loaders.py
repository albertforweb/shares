import torch
import torch.utils.data as data
import torch.utils.data.dataset as dataset
import numpy as np
import pickle
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

class Nav_Dataset(dataset.Dataset):
    def __init__(self):
        self.data = np.genfromtxt('saved/training_data.csv', delimiter=',')
# STUDENTS: it may be helpful for the final part to balance the distribution of your collected data
        # self.balance()
        # normalize data and save scaler for inference
        self.scaler = MinMaxScaler()
        self.normalized_data = self.scaler.fit_transform(self.data) #fits and transforms
        pickle.dump(self.scaler, open("saved/scaler.pkl", "wb")) #save to normalize at inference

    def balance(self):
        good = self.data[self.data[:,-1] == 0]
        bad = self.data[self.data[:,-1] == 1]
        total = len(self.data)
        cntgood = len(good)
        cntbad = len(bad)
        pergood = cntgood/total
        perbad = cntbad/total
        # keep good:bad = 60:40
        ratio = 0.0
        if cntgood < cntbad:
            ratio = 0.5
            cnt_del = ((1-ratio)*cntbad - ratio*cntgood)/(1-ratio)
            #remove bad
            ids = np.random.choice(bad.shape[0], cntbad-int(cnt_del), replace=False)
            keep = bad[ids,:]
            all = np.concatenate((good, keep), axis=0)
            self.data = all
            pass
        else:
            ratio = 0.5
            cnt_del = ((1-ratio)*cntgood - ratio*cntbad)/(1-ratio)
            # remove good
            ids = np.random.choice(good.shape[0], cntgood-int(cnt_del), replace=False)
            keep = good[ids,:]
            all = np.concatenate((keep, bad), axis=0)
            self.data = all
            pass
        pass


    def __len__(self):
# STUDENTS: __len__() returns the length of the dataset
        return len(self.data)
        pass

    def __getitem__(self, idx):
        if not isinstance(idx, int):
            idx = idx.item()
# STUDENTS: for this example, __getitem__() must return a dict with entries {'input': x, 'label': y}
# x and y should both be of type float32. There are many other ways to do this, but to work with autograding
# please do not deviate from these specifications.
        features = self.normalized_data[idx][0:6]
        target = self.normalized_data[idx][6]
        input = torch.tensor([float(x) for x in features], dtype=torch.float32)
        label = torch.tensor(float(target),dtype=torch.float32)
        return {'input': input, 'label':label}

class Data_Loaders():
    def __init__(self, batch_size):
        self.nav_dataset = Nav_Dataset()
# STUDENTS: randomly split dataset into two data.DataLoaders, self.train_loader and self.test_loader
# make sure your split can handle an arbitrary number of samples in the dataset as this may vary
        total = len(self.nav_dataset)
        train_size = int(0.8 * total)
        test_size = total - train_size
        train_dataset, test_dataset = data.random_split(self.nav_dataset, [train_size, test_size])

        self.train_loader = data.DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
        self.test_loader = data.DataLoader(test_dataset, batch_size=batch_size, shuffle=True)

        # train_sampler = self.balance(train_dataset)
        # test_sampler = self.balance(test_dataset)
        # self.train_loader = data.DataLoader(train_dataset, sampler=train_sampler, batch_size=batch_size, pin_memory=True, shuffle=(train_sampler==None))
        # self.test_loader =  data.DataLoader(test_dataset, sampler=test_sampler, batch_size=batch_size, pin_memory=True, shuffle=(test_sampler==None))

    def balance(self, data):
        ds = np.take(data.dataset.normalized_data, data.indices,0)
        good = ds[ds[:,-1]==0]
        bad = ds[ds[:,-1]==1]
        class_distributions={
            'good':len(good),
            'bad':len(bad)
        }
        plt.figure(figsize=(15,8))
        sns.barplot(data=pd.DataFrame.from_dict([class_distributions]).melt(), 
                    x="variable", y="value", hue="variable").\
                    set_title('good/bad Class Distribution')
        # plt.show()
        class_sample_counts = [len(good), len(bad)]
        # compute weight for all the samples in the dataset
        # samples_weights contain the probability for each example in dataset to be sampled  
        # shouldnt we do highestclass/class_c for all classes? that is do :
        # [dt_train.fake_sample_count/dt_train.real_sample_count, dt_train.fake_sample_count/dt_train.fake_sample_count]
        class_weights = 1./torch.Tensor(class_sample_counts)
        # get list of all labels 
        targets = ds[:,-1].astype(np.int64)
        labels, counts = np.unique(targets, return_counts=True)
        class_weights = [sum(counts)/c for c in counts]
        # then get the weight for each target!
        samples_weight = [class_weights[class_id] for class_id in targets]
        
        sampler = torch.utils.data.WeightedRandomSampler(samples_weight, len(samples_weight), replacement=True)
        return sampler
        pass

def main():
    batch_size = 16
    data_loaders = Data_Loaders(batch_size)
    # STUDENTS : note this is how the dataloaders will be iterated over, and cannot be deviated from
    for idx, sample in enumerate(data_loaders.train_loader):
        _, _ = sample['input'], sample['label']
    for idx, sample in enumerate(data_loaders.test_loader):
        _, _ = sample['input'], sample['label']

if __name__ == '__main__':
    main()
