from Data_Loaders import Data_Loaders
from Networks import Action_Conditioned_FF

import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import numpy as np



def train_model(no_epochs,round = 1):
    print("train round {}".format(round))
    model = Action_Conditioned_FF()
    print(model)

    batch_size = 10

    # loss_function = nn.BCELoss()
    loss_function = nn.BCEWithLogitsLoss()

    # learning_rate = 0.0002     
    # optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)
    
    learning_rate = 0.0003
    optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

    data_loaders = Data_Loaders(batch_size)

    train_losses=[]
    train_accuracy=[]
    valid_losses=[]
    valid_accuracy = []
    for epoch_i in range(no_epochs):
        model.train()
        loss_of_train = 0.0
        accuracy = 0.0
        #for idx, sample in enumerate(data_loaders.train_loader): # sample['input'] and sample['label']
        for sample in data_loaders.train_loader:
            input = sample['input']
            label = sample['label']
            optimizer.zero_grad()
            output = model(input)
            # loss
            loss = loss_function(output, label.unsqueeze(1))
            # accuracy
            acc = model.accuracy(output, label.unsqueeze(1))
            
            loss.backward()
            optimizer.step()
            
            loss_of_train += loss.item()
            accuracy += acc.item()

        size = len(data_loaders.train_loader)
        loss_of_train /= size
        accuracy = accuracy / size
        train_losses.append(loss_of_train)
        train_accuracy.append(accuracy)

        test_loss = 0
        test_acc = 0
        model.eval()
        with torch.no_grad():
            for sample in data_loaders.test_loader:
                X_batch, y_batch = sample['input'],sample['label']
                y_test_pred = model(X_batch)
            
                loss = loss_function(y_test_pred, y_batch.unsqueeze(1))
                acc = model.accuracy(y_test_pred, y_batch.unsqueeze(1))
                test_loss += loss.item()
                test_acc += acc.item()

        size = len(data_loaders.test_loader)
        avg_loss = test_loss/size
        avg_acc =  test_acc/size
        valid_losses.append(avg_loss)
        valid_accuracy.append(avg_acc)

        print(f'Epoch {epoch_i+0:03}: | Train Loss: {loss_of_train:.5f} | Acc: {accuracy:.3f} | Test Loss: {avg_loss:.5f} | Acc: {avg_acc:.3f}')

    torch.save(model.state_dict(), "saved/saved_model.pkl", _use_new_zipfile_serialization=False)

    x_axis = [i for i in range(no_epochs)]
    
    plt.clf()
    fig, ax = plt.subplots()
    plt.plot(x_axis,train_losses,label="training loss")
    plt.plot(x_axis, valid_losses,label="validation loss")
    plt.legend()
    text = "{}\nepoch : {}\nbatch : {}\nlr : {}\nloss : {}\noptim : {}".format(model, no_epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    plt.text(0.1,0.5, text, ha="left", va="center", transform=ax.transAxes)
    name = "train {} - epoch@{},batch@{},lr@{},loss@{},optim@{}".format(round, no_epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    name = name.replace('@',' ').replace(',', ' ').replace('.','-')
    plt.title(name)  
    # plt.show()
    plt.savefig(name)
    
    plt.clf()
    plt.plot(x_axis, train_accuracy,label="train accuracy")
    plt.plot(x_axis, valid_accuracy,label="test accuracy")
    plt.legend()
    name = "test {} - epoch@{},batch@{},lr@{},loss@{},optim@{}".format(round, no_epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    name = name.replace('@',' ').replace(',', ' ').replace('.','-')
    plt.title(name)  
    # plt.show()
    plt.savefig(name)

def runId():
    import os
    import glob
    folder = os.path.dirname(os.path.abspath(__file__))
    trains = glob.glob(folder + "/train*.png")
    return 1 + len(trains)

if __name__ == '__main__':

    no_epochs = 250
    rounds=1
    start = runId()
    end = start+rounds
    for r in range(start,end):
        train_model(no_epochs, r)