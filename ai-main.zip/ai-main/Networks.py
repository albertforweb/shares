import torch
import torch.nn as nn


class Action_Conditioned_FF(nn.Module):
#     def __init__111(self):
# # STUDENTS: __init__() must initiatize nn.Module and define your network's
# # custom architecture
#         super(Action_Conditioned_FF,self).__init__()
#         # 5 sensor values, 1 steering angle value
#         self.input_size = 6
#         # 200 neurons in hidden layer
#         self.hidden_size = 200
#         # one neurn in output
#         self.output_size = 1

#         self.layer_1 = nn.Linear(self.input_size, self.hidden_size) 
#         self.layer_2 = nn.Linear(self.hidden_size, self.hidden_size)
#         self.layer_out = nn.Linear(self.hidden_size, self.output_size) 
        
#         # self.act1 = nn.ReLU()
#         self.act1 = nn.RReLU()
#         # self.sigmoid = nn.Sigmoid()



#     def forward111(self, input):
# # STUDENTS: forward() must complete a single forward pass through your network
# # and return the output which should be a tensor
#         x = self.act1(self.layer_1(input))
#         x = self.act1(self.layer_2(x))
#         x = self.layer_out(x)
#         # x = self.sigmoid(x)
#         return x


    # def accuracy_old(self, y_pred, y_label):
    #     y_pred = torch.round(torch.sigmoid(y_pred))
    #     # y_pred = torch.round(y_pred)
    #     corrects = (y_pred == y_label).sum().float()
    #     accuracy = corrects/y_label.shape[0]
    #     accuracy = torch.round(accuracy * 100)
    #     return accuracy

    def __init__(self):
# STUDENTS: __init__() must initiatize nn.Module and define your network's
# custom architecture
        super(Action_Conditioned_FF,self).__init__()
        # 5 sensor values, 1 steering angle value
        self.input_size = 6
        # 200 neurons in hidden layer
        self.hidden_size = 200
        # one neurn in output
        self.output_size = 1

        self.stack = nn.Sequential(
            nn.Linear(self.input_size, self.hidden_size),
            nn.ReLU(),
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.ReLU(),
            nn.Linear(self.hidden_size, self.output_size),
            # nn.Sigmoid()
        )


    def forward(self, input):
# STUDENTS: forward() must complete a single forward pass through your network
# and return the output which should be a tensor
        x = self.stack(input)
        # x = self.sigmoid(x)
        return x


    def accuracy(self, y_pred, y_label):
        y_pred = torch.sigmoid(y_pred)
        y_pred = torch.round(y_pred)
        corrects = (y_pred == y_label).sum().float()
        accuracy = corrects/y_label.shape[0]
        accuracy = torch.round(accuracy * 100)
        return accuracy

    def evaluate(self, model, test_loader, loss_function):
# STUDENTS: evaluate() must return the loss (a value, not a tensor) over your testing dataset. Keep in
# mind that we do not need to keep track of any gradients while evaluating the
# model. loss_function will be a PyTorch loss function which takes as argument the model's
# output and the desired output.
        loss = 0
        with torch.no_grad():
            for idx, sample in enumerate(test_loader):
                input, label = sample['input'], sample['label']
                output = model(input)
                loss_data = loss_function(output, torch.reshape(label, output.size()))
                loss += loss_data.item()

        size = len(test_loader)
        if size:
            loss = loss / size
        return loss

def main():
    model = Action_Conditioned_FF()

if __name__ == '__main__':
    main()
