import torch
import torch.nn as nn


class Action_Conditioned_FF(nn.Module):
    def __init__(self):
        super(Action_Conditioned_FF, self).__init__()
        self.input_size = 6
        # 200 neurons in hidden layer
        self.hidden_size = 200
        # one neurn in output
        self.output_size = 1

        self.layer_1 = nn.Linear(self.input_size, self.hidden_size) 
        self.layer_2 = nn.Linear(self.hidden_size, self.hidden_size)
        self.layer_out = nn.Linear(self.hidden_size, self.output_size) 
        
        self.activate = nn.ReLU()
        
    def forward(self, inputs):
        x = self.activate(self.layer_1(inputs))
        x = self.activate(self.layer_2(x))
        x = self.layer_out(x)
        
        return x

    def evaluate(self, model, test_loader, loss_function):
        loss = 0
        with torch.no_grad():
            for idx, sample in enumerate(test_loader):
                input, label = sample['input'], sample['label']
                output = model(input)
                y_pred_tag = torch.round(torch.sigmoid(output))
                loss_data = loss_function(y_pred_tag, torch.reshape(label, output.size()))
                loss += loss_data.item()

        size = len(test_loader)
        if size:
            loss = loss / size
        return loss

class Action_Conditioned_FF_old(nn.Module):
    def __init__(self):
# STUDENTS: __init__() must initiatize nn.Module and define your network's
# custom architecture
        super(Action_Conditioned_FF,self).__init__()
        # 5 sensor values, 1 steering angle value
        self.input_size = 6
        # 200 neurons in hidden layer
        self.hidden_size = 200
        # one neurn in output
        self.output_size = 1

    # simple network
        self.input_to_hidden = nn.Linear(self.input_size, self.hidden_size)
        self.nonlinear_activation = nn.Sigmoid()
        self.hidden_to_output = nn.Linear(self.hidden_size, self.output_size)
        pass


    def forward(self, input):
# STUDENTS: forward() must complete a single forward pass through your network
# and return the output which should be a tensor
        
        hidden = self.input_to_hidden(input.float())
        hidden = self.nonlinear_activation(hidden)
        output = self.hidden_to_output(hidden)
        return output.float()

    def evaluate(self, model, test_loader, loss_function):
# STUDENTS: evaluate() must return the loss (a value, not a tensor) over your testing dataset. Keep in
# mind that we do not need to keep track of any gradients while evaluating the
# model. loss_function will be a PyTorch loss function which takes as argument the model's
# output and the desired output.
        loss = 0
        with torch.no_grad():
            for idx, sample in enumerate(test_loader):
                input, label = sample['input'], sample['label']
                output = model(input)
                loss_data = loss_function(output, torch.reshape(label, output.size()))
                loss += loss_data.item()

        size = len(test_loader)
        if size:
            loss = loss / size
        return loss

def main():
    model = Action_Conditioned_FF()

if __name__ == '__main__':
    main()
