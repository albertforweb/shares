import torch
import torch.nn as nn

from Data_Loaders import Data_Loaders

import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import numpy as np

from sklearn.metrics import accuracy_score

class Action_Conditioned_FF(nn.Module):
    def __init__(self):
        super(Action_Conditioned_FF, self).__init__()
        self.input_size = 6
        # 200 neurons in hidden layer
        self.hidden_size = 200
        # one neurn in output
        self.output_size = 1

        self.layer_1 = nn.Linear(self.input_size, self.hidden_size) 
        self.layer_2 = nn.Linear(self.hidden_size, self.hidden_size)
        self.layer_out = nn.Linear(self.hidden_size, self.output_size) 
        
        self.relu = nn.ReLU()
        self.sigmoid = nn.Sigmoid()
        
    def forward(self, inputs):
        x = self.relu(self.layer_1(inputs))
        x = self.relu(self.layer_2(x))
        x = self.layer_out(x)
        x = self.sigmoid(x)
        
        return x

def cal_accuracy(y_pred, y_label):
    # use sigmoid to convert output value to probability, round to get class
    # y_pred_class = torch.round(torch.sigmoid(y_pred))
    #y_pred_class = torch.sigmoid(y_pred)
    y_pred_class = torch.round(y_pred)
    corrects = (y_pred_class == y_label).sum().float()
    accuracy = corrects/y_label.shape[0]
    accuracy = torch.round(accuracy * 100)
    return accuracy

def train(model, train_loader, loss_function, optimizer):
    
    model.train()

    total_loss = 0.0
    total_accuracy = 0.0
    for sample in train_loader:
        input = sample['input']
        label = sample['label']
        optimizer.zero_grad()
        output = model(input)

        target = label.unsqueeze(1)
        loss = loss_function(output, target)

        loss.backward()
        optimizer.step()

        total_loss += loss.item()
        total_accuracy += cal_accuracy(output,target).item()

    size = len(train_loader)
    avg_accuracy = total_accuracy / size
    avg_loss = total_loss / size

    return avg_accuracy,avg_loss


def evaluate(model, test_loader, loss_function):
    model.eval()
    total_loss = 0.0
    total_accuracy = 0.0
    with torch.no_grad():
        for idx, sample in enumerate(test_loader):
            input = sample['input']
            label = sample['label']
            output = model(input)
            target = label.unsqueeze(1)
            loss = loss_function(output, target)
            total_loss += loss.item()
            total_accuracy += cal_accuracy(output,  target).item()

    size = len(test_loader)
    avg_accuracy = total_accuracy / size
    avg_loss = total_loss / size
    return avg_accuracy, avg_loss

def train_model():
    epochs = 100
    batch_size = 10
    learning_rate = 0.001

    model = Action_Conditioned_FF()
    loss_function = nn.BCELoss() #nn.BCEWithLogitsLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)

    data_loaders = Data_Loaders(batch_size)
    train_loader = data_loaders.train_loader
    test_loader = data_loaders.test_loader


    train_losses=[]
    train_accuracy=[]
    valid_losses=[]
    valid_accuracy = []
    for i in range(epochs):
        train_acc, train_loss = train(model,train_loader,loss_function, optimizer)
        train_losses.append(train_loss)
        train_accuracy.append(train_acc)
        
        test_acc, test_loss = evaluate(model,test_loader, loss_function)
        valid_losses.append(test_loss)
        valid_accuracy.append(test_acc)
        print(f'Epoch {i+0:03}: | Train Loss: {train_loss:.5f} | Acc: {train_acc:.3f} | Test Loss: {test_loss:.5f} | Acc: {test_acc:.3f}')

    torch.save(model.state_dict(), "saved/saved_model.pkl", _use_new_zipfile_serialization=False)

    x_axis = [i for i in range(epochs)]
    plt.plot(x_axis,train_losses,label="training loss")
    plt.plot(x_axis, valid_losses,label="validation loss")
    plt.legend()
    name = "train - epoch@{},batch@{},lr@{},loss@{},optim@{}".format(epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    name = name.replace('@',' ').replace(',', ' ').replace('.','-')
    plt.title(name)  
    # plt.show()
    plt.savefig(name)
    
    plt.clf()
    plt.plot(x_axis, train_accuracy,label="train accuracy")
    plt.plot(x_axis, valid_accuracy,label="test accuracy")
    plt.legend()
    name = "test - epoch@{},batch@{},lr@{},loss@{},optim@{}".format(epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    name = name.replace('@',' ').replace(',', ' ').replace('.','-')
    plt.title(name)  
    # plt.show()
    plt.savefig(name)

if __name__ == '__main__':
    train_model()
    pass