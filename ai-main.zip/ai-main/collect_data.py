# ************** STUDENTS EDIT THIS FILE **************

from SteeringBehaviors import Wander
import SimulationEnvironment as sim

import numpy as np
import pygame

def collect_training_data(total_actions):
    #set-up environment
    sim_env = sim.SimulationEnvironment()

    #robot control
    action_repeat = 100
    steering_behavior = Wander(action_repeat)

    num_params = 7
    #STUDENTS: network_params will be used to store your training data
    # a single sample will be comprised of: sensor_readings, action, collision
    # the 5 distance sensor readings, the action, and whether or not a collision occurred (0: no collision, 1: collision).
    network_params = [[0]*num_params]*total_actions

    for action_i in range(total_actions):
        for event in pygame.event.get():
            pass
        progress = 100*float(action_i)/total_actions
        print(f'Collecting Training Data {progress}%   ', end="\r", flush=True)

        #steering_force is used for robot control only
        action, steering_force = steering_behavior.get_action(action_i, sim_env.robot.body.angle)
        collision = 0
        for action_timestep in range(action_repeat):
            if action_timestep == 0:
                _, collision, sensor_readings = sim_env.step(steering_force)
            else:
                _, collision, _ = sim_env.step(steering_force)

            if collision:
                steering_behavior.reset_action()
                #STUDENTS NOTE: this statement only EDITS collision of PREVIOUS action
                #if current action is very new.
                if action_timestep < action_repeat * .3: #in case prior action caused collision
                    network_params[-1][-1] = collision #share collision result with prior action
                print("\ncollision at {} : {}\n".format(action_i, collision))
                break


        #STUDENTS: Update network_params.
        network_params[action_i] = sensor_readings.tolist()
        network_params[action_i].append(action)
        network_params[action_i].append(collision)
        print("\n{}\n".format(network_params[action_i]))


    #STUDENTS: Save .csv here. Remember rows are individual samples, the first 5
    #columns are sensor values, the 6th is the action, and the 7th is collision.
    #Do not title the columns. Your .csv should look like the provided sample.
    # print(network_params)
    #np.savetxt("submission.csv", np.asarray(network_params), delimiter=",", fmt="%f")
    np.savetxt("saved/training_data.csv", np.asarray(network_params), delimiter=",", fmt="%f")






if __name__ == '__main__':
    total_actions = 2000
    collect_training_data(total_actions)
