import torch
import torch.nn as nn

from Data_Loaders import Data_Loaders

import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import numpy as np


class Action_Conditioned_FF(nn.Module):
    def __init__(self):
        super(Action_Conditioned_FF, self).__init__()
        self.input_size = 6
        # 200 neurons in hidden layer
        self.hidden_size = 200
        # one neurn in output
        self.output_size = 1

        self.layer_1 = nn.Linear(self.input_size, self.hidden_size) 
        self.layer_2 = nn.Linear(self.hidden_size, self.hidden_size)
        self.layer_out = nn.Linear(self.hidden_size, self.output_size) 
        
        self.activate = nn.ReLU()
        
    def forward(self, inputs):
        x = self.activate(self.layer_1(inputs))
        x = self.activate(self.layer_2(x))
        x = self.layer_out(x)
        
        return x

    def evaluate(self, model, test_loader, loss_function):
        loss = 0
        with torch.no_grad():
            for idx, sample in enumerate(test_loader):
                input, label = sample['input'], sample['label']
                output = model(input)
                y_pred_tag = torch.round(torch.sigmoid(output))
                loss_data = loss_function(y_pred_tag, torch.reshape(label, output.size()))
                loss += loss_data.item()

        size = len(test_loader)
        if size:
            loss = loss / size
        return loss



def cal_accuracy(y_pred, y_label):
    # use sigmoid to convert output value to probability, round to get class
    y_pred_class = torch.round(torch.sigmoid(y_pred))
    corrects = (y_pred_class == y_label).sum().float()
    accuracy = corrects/y_label.shape[0]
    accuracy = torch.round(accuracy * 100)
    return accuracy


def train_model():
    model = Action_Conditioned_FF()
    no_epochs = 100
    batch_size = 25
    learning_rate = 0.0001 
    loss_function = nn.BCEWithLogitsLoss()
    optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)

    data_loaders = Data_Loaders(batch_size)

    epochs=[]
    train_losses=[]
    train_accuracy=[]
    valid_losses=[]
    valid_accuracy = []
    for epoch_i in range(no_epochs):
        epochs.append(epoch_i)
        model.train()
        loss_of_train = 0.0
        accuracy = 0.0
        for idx, sample in enumerate(data_loaders.train_loader): # sample['input'] and sample['label']
            input = sample['input']
            label = sample['label']
            optimizer.zero_grad()
            output = model(input)
            # loss
            loss = loss_function(output, label.unsqueeze(1))
            # accuracy
            acc = cal_accuracy(output, label.unsqueeze(1))
            
            loss.backward()
            optimizer.step()
            
            loss_of_train += loss.item()
            accuracy += acc.item()

        size = len(data_loaders.train_loader)
        loss_of_train /= size
        accuracy = accuracy / size
        train_losses.append(loss_of_train)
        train_accuracy.append(accuracy)

        test_loss = 0
        test_acc = 0
        model.eval()
        with torch.no_grad():
            for sample in data_loaders.test_loader:
                X_batch, y_batch = sample['input'],sample['label']
                y_test_pred = model(X_batch)
            
                loss = loss_function(y_test_pred, y_batch.unsqueeze(1))
                acc = cal_accuracy(y_test_pred, y_batch.unsqueeze(1))
                test_loss += loss.item()
                test_acc += acc.item()

        size = len(data_loaders.test_loader)
        avg_loss = test_loss/size
        avg_acc =  test_acc/size
        valid_losses.append(avg_loss)
        valid_accuracy.append(avg_acc)

        print(f'Epoch {epoch_i+0:03}: | Train Loss: {loss_of_train:.5f} | Acc: {accuracy:.3f} | Test Loss: {avg_loss:.5f} | Acc: {avg_acc:.3f}')

    torch.save(model.state_dict(), "saved/saved_model.pkl", _use_new_zipfile_serialization=False)

    plt.plot(epochs,train_losses,label="training loss")
    plt.plot(epochs, valid_losses,label="validation loss")

    plt.legend()
    name = "train - epoch@{},batch@{},lr@{},loss@{},optim@{}".format(no_epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    name = name.replace('@',' ').replace(',', ' ').replace('.','-')
    plt.title(name)  
    # plt.show()
    plt.savefig(name)
    
    plt.clf()
    plt.plot(epochs, train_accuracy,label="train accuracy")
    plt.plot(epochs, valid_accuracy,label="test accuracy")
    plt.legend()
    name = "test - epoch@{},batch@{},lr@{},loss@{},optim@{}".format(no_epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    name = name.replace('@',' ').replace(',', ' ').replace('.','-')
    plt.title(name)  
    # plt.show()
    plt.savefig(name)

if __name__ == '__main__':
    train_model()