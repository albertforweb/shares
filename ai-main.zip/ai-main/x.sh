
i=1
while [ $i -le 1 ] 
do 
echo run $i round ...
python3 train_model.py
# python3 goal_seeking.py
# cat saved/collisions_data.csv >> saved/training_data.csv
i=$(( $i + 1 ))
done