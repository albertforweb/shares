from sklearn.metrics import confusion_matrix
from sklearn.metrics.classification import accuracy_score
from sklearn.preprocessing import MinMaxScaler

import pickle
import numpy as np
import torch
import torch
import torch.nn as nn
import torch.utils.data as data
import torch.utils.data.dataset as dataset

class Action_Conditioned_FF(nn.Module):
    def __init__(self):
# STUDENTS: __init__() must initiatize nn.Module and define your network's
# custom architecture
        super(Action_Conditioned_FF,self).__init__()
        # 5 sensor values, 1 steering angle value
        self.input_size = 6
        # 200 neurons in hidden layer
        self.hidden_size = 200
        # one neurn in output
        self.output_size = 1

        self.stack = nn.Sequential(
            nn.Linear(self.input_size, self.hidden_size),
            nn.ReLU(),
            nn.Linear(self.hidden_size, self.hidden_size),
            nn.ReLU(),
            nn.Linear(self.hidden_size, self.output_size),
            # nn.Sigmoid()
        )


    def forward(self, input):
# STUDENTS: forward() must complete a single forward pass through your network
# and return the output which should be a tensor
        x = self.stack(input)
        # x = self.sigmoid(x)
        return x


    def accuracy(self, y_pred, y_label):
        y_pred = torch.sigmoid(y_pred)
        y_pred = torch.round(y_pred)
        corrects = (y_pred == y_label).sum().float()
        accuracy = corrects/y_label.shape[0]
        accuracy = torch.round(accuracy * 100)
        return accuracy


class Nav_Dataset(dataset.Dataset):
    def __init__(self, datafile):
        self.data = np.genfromtxt(datafile, delimiter=',')
# STUDENTS: it may be helpful for the final part to balance the distribution of your collected data
        # self.balance()
        # normalize data and save scaler for inference
        self.scaler = MinMaxScaler()
        self.normalized_data = self.scaler.fit_transform(self.data) #fits and transforms


    def __len__(self):
# STUDENTS: __len__() returns the length of the dataset
        return len(self.normalized_data)
        pass

    def __getitem__(self, idx):
        if not isinstance(idx, int):
            idx = idx.item()
# STUDENTS: for this example, __getitem__() must return a dict with entries {'input': x, 'label': y}
# x and y should both be of type float32. There are many other ways to do this, but to work with autograding
# please do not deviate from these specifications.
        features = self.normalized_data[idx][0:6]
        target = self.normalized_data[idx][6]
        input = torch.tensor([float(x) for x in features], dtype=torch.float32)
        label = torch.tensor(float(target),dtype=torch.float32)
        return {'input': input, 'label':label}

class Data_Loaders():
    def __init__(self, datafile, batch_size):
        self.nav_dataset = Nav_Dataset(datafile)
        self.loader = data.DataLoader(self.nav_dataset, batch_size=batch_size, shuffle=True)

# load data
data_loader = Data_Loaders("saved/training_data_stock.csv", 20).loader


#load model
model = Action_Conditioned_FF()
model.load_state_dict(torch.load('saved/saved_model.pkl'))
model.eval()

# evaluate
loss = 0
loss_function = nn.BCEWithLogitsLoss()
actual=[]
predicts=[]
with torch.no_grad():
    for idx, sample in enumerate(data_loader):
        input = sample['input']
        label = sample['label']
        output = model(input)
        preds = torch.round(torch.sigmoid(output))
        preds = preds.flatten()
        loss_data = loss_function(preds, label)
        loss += loss_data.item()
        actual = np.concatenate((actual, label.detach().numpy()))
        predicts = np.concatenate((predicts, preds.detach().numpy()))

size = len(data_loader)
if size:
    loss = loss / size

score = accuracy_score(actual, predicts)
cm = confusion_matrix(actual, predicts).ravel()
print("accuracy {} , matrix(TN,FP,FN,TP) {}".format(score, cm))