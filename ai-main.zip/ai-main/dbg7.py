from warnings import simplefilter 
simplefilter(action='ignore', category=DeprecationWarning)

import torch

from torch import Tensor
from sklearn.model_selection import KFold
from typing import Iterator, Optional, Sequence, List, TypeVar, Generic, Sized

from torch.nn.modules.fold import Fold

T_co = TypeVar('T_co', covariant=True)

import torch
import torch.utils.data as data
import torch.utils.data.dataset as dataset
import numpy as np
import pickle
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns

import torch
import torch.nn as nn


class Action_Conditioned_FF(nn.Module):
    def __init__(self):
# STUDENTS: __init__() must initiatize nn.Module and define your network's
# custom architecture
        super(Action_Conditioned_FF,self).__init__()
        # 5 sensor values, 1 steering angle value
        self.input_size = 6
        # 200 neurons in hidden layer
        self.hidden_size = 200
        # one neurn in output
        self.output_size = 1

        self.layer_1 = nn.Linear(self.input_size, self.hidden_size) 
        self.layer_2 = nn.Linear(self.hidden_size, self.hidden_size)
        self.layer_out = nn.Linear(self.hidden_size, self.output_size) 
        
        self.act1 = nn.ReLU()
        # self.act1 = nn.ELU()
        # self.sigmoid = nn.Sigmoid()



    def forward(self, input):
# STUDENTS: forward() must complete a single forward pass through your network
# and return the output which should be a tensor
        x = self.act1(self.layer_1(input))
        x = self.act1(self.layer_2(x))
        x = self.layer_out(x)
        # x = self.sigmoid(x)
        return x



    def accuracy_old(self, y_pred, y_label):
        y_pred = torch.round(torch.sigmoid(y_pred))
        # y_pred = torch.round(y_pred)
        corrects = (y_pred == y_label).sum().float()
        accuracy = corrects/y_label.shape[0]
        accuracy = torch.round(accuracy * 100)
        return accuracy

    def accuracy(self, y_pred, y_label):
        y_pred = torch.sigmoid(y_pred)
        y_pred = torch.round(y_pred)
        corrects = (y_pred == y_label).sum().float()
        accuracy = corrects/y_label.shape[0]
        accuracy = torch.round(accuracy * 100)
        return accuracy

    def evaluate(self, model, test_loader, loss_function):
# STUDENTS: evaluate() must return the loss (a value, not a tensor) over your testing dataset. Keep in
# mind that we do not need to keep track of any gradients while evaluating the
# model. loss_function will be a PyTorch loss function which takes as argument the model's
# output and the desired output.
        loss = 0
        with torch.no_grad():
            for idx, sample in enumerate(test_loader):
                input, label = sample['input'], sample['label']
                output = model(input)
                loss_data = loss_function(output, torch.reshape(label, output.size()))
                loss += loss_data.item()

        size = len(test_loader)
        if size:
            loss = loss / size
        return loss


class Nav_Dataset(dataset.Dataset):
    def __init__(self):
        self.data = np.genfromtxt('saved/training_data.csv', delimiter=',')
# STUDENTS: it may be helpful for the final part to balance the distribution of your collected data
        # self.balance()
        # normalize data and save scaler for inference
        self.scaler = MinMaxScaler()
        self.normalized_data = self.scaler.fit_transform(self.data) #fits and transforms
        # pickle.dump(self.scaler, open("saved/scaler.pkl", "wb")) #save to normalize at inference

    def __len__(self):
# STUDENTS: __len__() returns the length of the dataset
        return len(self.normalized_data)
        pass

    def __getitem__(self, idx):
        if not isinstance(idx, int):
            idx = idx.item()
# STUDENTS: for this example, __getitem__() must return a dict with entries {'input': x, 'label': y}
# x and y should both be of type float32. There are many other ways to do this, but to work with autograding
# please do not deviate from these specifications.
        features = self.normalized_data[idx][0:6]
        target = self.normalized_data[idx][6]
        input = torch.tensor([float(x) for x in features], dtype=torch.float32)
        label = torch.tensor(float(target),dtype=torch.float32)
        return {'input': input, 'label':label}

class Sampler(Generic[T_co]):
    r"""Base class for all Samplers.

    Every Sampler subclass has to provide an :meth:`__iter__` method, providing a
    way to iterate over indices of dataset elements, and a :meth:`__len__` method
    that returns the length of the returned iterators.

    .. note:: The :meth:`__len__` method isn't strictly required by
              :class:`~torch.utils.data.DataLoader`, but is expected in any
              calculation involving the length of a :class:`~torch.utils.data.DataLoader`.
    """

    def __init__(self, data_source: Optional[Sized]) -> None:
        pass

    def __iter__(self) -> Iterator[T_co]:
        raise NotImplementedError
        
class SubsetRandomSampler(Sampler[int]):
    r"""Samples elements randomly from a given list of indices, without replacement.

    Args:
        indices (sequence): a sequence of indices
        generator (Generator): Generator used in sampling.
    """
    indices: Sequence[int]

    def __init__(self, indices: Sequence[int], generator=None) -> None:
        self.indices = indices
        self.generator = generator

    def __iter__(self):
        return (self.indices[i] for i in torch.randperm(len(self.indices), generator=self.generator))

    def __len__(self):
        return len(self.indices) 

def runId():
    import os
    import glob
    folder = os.path.dirname(os.path.abspath(__file__))
    trains = glob.glob(folder + "/train*.png")
    return 1 + len(trains)

round = runId()
k_folds=2
no_epochs=100
batch_size=25
learning_rate = 0.0001
nav_dataset = Nav_Dataset()
model = Action_Conditioned_FF()
loss_function = nn.BCEWithLogitsLoss()
# optimizer = torch.optim.SGD(model.parameters(), lr=learning_rate)
optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

# train_dataset = nav_dataset
# val_dataset = nav_dataset
dataset = nav_dataset
kfold = KFold(n_splits=k_folds, shuffle=True)
for fold,(train_ids, test_ids) in enumerate(kfold.split(dataset)):
    

    # print('#'*35); print('############ FOLD ',fold+1,' #############'); print('#'*35);
    # train_loader = torch.utils.data.DataLoader(dataset=train_dataset, 
    #                                         batch_size=batch_size,
    #                                         num_workers=1,
    #                                         sampler = SubsetRandomSampler(tr_idx)
    #                                     )
    # val_loader = torch.utils.data.DataLoader(dataset=val_dataset, 
    #                                         batch_size=batch_size,
    #                                         num_workers=1,
    #                                         sampler = SubsetRandomSampler(val_idx)
                                        # )
    # Sample elements randomly from a given list of ids, no replacement.
    train_subsampler = torch.utils.data.SubsetRandomSampler(train_ids)
    test_subsampler = torch.utils.data.SubsetRandomSampler(test_ids)
    
    # Define data loaders for training and testing data in this fold
    train_loader  = torch.utils.data.DataLoader(
                      dataset, 
                      batch_size=batch_size, sampler=train_subsampler)
    val_loader = torch.utils.data.DataLoader(
                      dataset,
                      batch_size=batch_size, sampler=test_subsampler)

    train_losses=[]
    train_accuracy=[]
    valid_losses=[]
    valid_accuracy = []
    for epoch_i in range(no_epochs):
        model.train()
        loss_of_train = 0.0
        accuracy = 0.0
        #for idx, sample in enumerate(data_loaders.train_loader): # sample['input'] and sample['label']
        for sample in train_loader:
            input = sample['input']
            label = sample['label']
            optimizer.zero_grad()
            output = model(input)
            # loss
            loss = loss_function(output, label.unsqueeze(1))
            # accuracy
            acc = model.accuracy(output, label.unsqueeze(1))
            
            loss.backward()
            optimizer.step()
            
            loss_of_train += loss.item()
            accuracy += acc.item()

        size = len(train_loader)
        loss_of_train /= size
        accuracy = accuracy / size
        train_losses.append(loss_of_train)
        train_accuracy.append(accuracy)

        test_loss = 0
        test_acc = 0
        model.eval()
        with torch.no_grad():
            for sample in val_loader:
                X_batch, y_batch = sample['input'],sample['label']
                y_test_pred = model(X_batch)
            
                loss = loss_function(y_test_pred, y_batch.unsqueeze(1))
                acc = model.accuracy(y_test_pred, y_batch.unsqueeze(1))
                test_loss += loss.item()
                test_acc += acc.item()

        size = len(val_loader)
        avg_loss = test_loss/size
        avg_acc =  test_acc/size
        valid_losses.append(avg_loss)
        valid_accuracy.append(avg_acc)

        print(f'Fold {fold+0:03} Epoch {epoch_i+0:03}: | Train Loss: {loss_of_train:.5f} | Acc: {accuracy:.3f} | Test Loss: {avg_loss:.5f} | Acc: {avg_acc:.3f}')

    # torch.save(model.state_dict(), "saved/saved_model.pkl", _use_new_zipfile_serialization=False)

    x_axis = [i for i in range(no_epochs)]
    
    plt.clf()
    fig, ax = plt.subplots()
    plt.plot(x_axis,train_losses,label="training loss")
    plt.plot(x_axis, valid_losses,label="validation loss")
    plt.legend()
    text = "{}\nfold : {}\nepoch : {}\nbatch : {}\nlr : {}\nloss : {}\noptim : {}".format(model, fold, no_epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    plt.text(0.1,0.5, text, ha="left", va="center", transform=ax.transAxes)
    name = "train {} - fold@{},epoch@{},batch@{},lr@{},loss@{},optim@{}".format(round, fold, no_epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    name = name.replace('@',' ').replace(',', ' ').replace('.','-')
    plt.title(name)  
    # plt.show()
    plt.savefig(name)
    
    plt.clf()
    plt.plot(x_axis, train_accuracy,label="train accuracy")
    plt.plot(x_axis, valid_accuracy,label="test accuracy")
    plt.legend()
    name = "test {} - fold@{},epoch@{},batch@{},lr@{},loss@{},optim@{}".format(round, fold,no_epochs,batch_size,learning_rate,loss_function.__class__.__name__,optimizer.__class__.__name__)
    name = name.replace('@',' ').replace(',', ' ').replace('.','-')
    plt.title(name)  
    # plt.show()
    plt.savefig(name)